package com.oc.professionalfinder.fragments.mainMenu

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.oc.professionalfinder.activities.LoginActivity
import com.oc.professionalfinder.adapters.TaskAdapter
import com.oc.professionalfinder.databinding.FragmentToDoBinding
import com.oc.professionalfinder.fragments.todo.ToDoDialogFragment
import com.oc.professionalfinder.model.ToDo
import com.oc.professionalfinder.model.User

class toDoFragment : Fragment(), ToDoDialogFragment.OnDialogNextBtnClickListener,
    TaskAdapter.TaskAdapterInterface {
    private val TAG = "toDoFragment"
    private lateinit var binding: FragmentToDoBinding
    private lateinit var dbReference: DatabaseReference
    private lateinit var dbRef: DatabaseReference
    private var popUpFragment: ToDoDialogFragment? = null
    private lateinit var auth: FirebaseAuth
    private lateinit var authId: String

    private lateinit var taskAdapter: TaskAdapter
    private lateinit var toDoItemList: MutableList<ToDo>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentToDoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()

        //get data from firebase
        getTaskFromFirebase()


        binding.addTaskBtn.setOnClickListener {

            if (popUpFragment != null)
                childFragmentManager.beginTransaction().remove(popUpFragment!!).commit()
            popUpFragment = ToDoDialogFragment()
            popUpFragment!!.setListener(this)

            popUpFragment!!.show(
                childFragmentManager,
                ToDoDialogFragment.TAG
            )

        }
    }

    private fun getTaskFromFirebase() {
        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                toDoItemList.clear()
                for (taskSnapshot in snapshot.children) {
                    val pulledTasks =
                        taskSnapshot.key?.let { ToDo(it, taskSnapshot.value.toString()) }

                    if (pulledTasks != null) {
                        toDoItemList.add(pulledTasks)
                    }

                }
                Log.d(TAG, "onDataChange: " + toDoItemList)
                taskAdapter.notifyDataSetChanged()

            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show()
            }


        })
    }

    private fun init() {

        auth = FirebaseAuth.getInstance()
        authId = auth.currentUser!!.uid
        dbRef = Firebase.database.reference.child("Tasks")
            .child(authId)


        binding.toDoRv.setHasFixedSize(true)
        binding.toDoRv.layoutManager = LinearLayoutManager(context)

        toDoItemList = mutableListOf()
        taskAdapter = TaskAdapter(toDoItemList)
        taskAdapter.setListener(this)
        binding.toDoRv.adapter = taskAdapter
    }

    // Whilst saving the new task, the task is saved to the user as jobRequest.
    override fun saveTask(todoTask: String, todoEdit: TextInputEditText) {
        val data = mutableMapOf<String, String>()
        data["jobRequest"] = todoTask
        dbReference = FirebaseDatabase.getInstance().getReference("User")
        dbReference.child(authId).updateChildren(data as MutableMap<String, Any>).addOnSuccessListener {
            dbRef
                .push().setValue(todoTask)
                .addOnCompleteListener {
                    if (it.isSuccessful) {
                        Toast.makeText(context, "Task Added Successfully", Toast.LENGTH_SHORT).show()
                        todoEdit.text = null

                    } else {
                        Toast.makeText(context, it.exception.toString(), Toast.LENGTH_SHORT).show()
                    }
                }
            popUpFragment!!.dismiss()
        }

    }


    override fun updateTask(toDoData: ToDo, todoEdit: TextInputEditText) {
        val map = HashMap<String, Any>()
        map[toDoData.taskId] = toDoData.task
        dbRef.updateChildren(map).addOnCompleteListener {
            if (it.isSuccessful) {
                Toast.makeText(context, "Updated Successfully", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, it.exception.toString(), Toast.LENGTH_SHORT).show()
            }
            popUpFragment!!.dismiss()
        }
    }

    // Deletes the jobRequest field from the current user whilst also deleting the selected task
    override fun onDeleteItemClicked(toDoData: ToDo, position: Int) {
            dbReference = FirebaseDatabase.getInstance().getReference("User")
            dbReference.child(authId).child("jobRequest").removeValue().addOnSuccessListener {
                dbRef.child(toDoData.taskId).removeValue().addOnCompleteListener {
                    if (it.isSuccessful) {
                        Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, it.exception.toString(), Toast.LENGTH_SHORT).show()
                    }
                }
            }
    }
    override fun onEditItemClicked(toDoData: ToDo, position: Int) {
        if (popUpFragment != null)
            childFragmentManager.beginTransaction().remove(popUpFragment!!).commit()

        popUpFragment = ToDoDialogFragment.newInstance(toDoData.taskId, toDoData.task)
        popUpFragment!!.setListener(this)
        popUpFragment!!.show(
            childFragmentManager,
            ToDoDialogFragment.TAG
        )
    }
}