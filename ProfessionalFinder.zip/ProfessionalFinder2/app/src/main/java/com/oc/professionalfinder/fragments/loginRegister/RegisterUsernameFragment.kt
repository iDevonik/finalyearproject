package com.oc.professionalfinder.fragments.loginRegister

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.oc.professionalfinder.R
import com.oc.professionalfinder.activities.LoginActivity
import com.oc.professionalfinder.databinding.FragmentRegisterUsernameBinding

class RegisterUsernameFragment: Fragment() {

    private lateinit var binding: FragmentRegisterUsernameBinding
    private lateinit var navControl: NavController


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRegisterUsernameBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            // Redirects user to the login screen if they click the sign in button.
            btnSignIn.setOnClickListener {
                val intent = Intent(activity, LoginActivity::class.java)
                startActivity(intent)
            }
            // On button press, validation check to see if the username is blank or contains any special characters/spaces that aren't full stops or hyphens  - if so the user is outputted with an error.
            btnNext.setOnClickListener {
                // Reset the error output if user has clicked the button again after correcting issues
                binding.usernameInput.isErrorEnabled = false
                fun isValidUsername(username: String): Boolean {
                    return username.matches(Regex("^[a-zA-Z.-]+\$"))
                }

                val usernameText = binding.usernameInputText.text.toString()
                if (isValidUsername(usernameText)) {
                    if ((usernameText).isNotEmpty()) {
                        val direction =
                            RegisterUsernameFragmentDirections.actionRegisterUsernameFragmentToRegisterActivity(
                                binding.usernameInputText.text.toString()
                            )
                        findNavController().navigate(direction)
                    }else {
                        binding.usernameInput.error = "Username field is blank."
                    }
                } else {
                    binding.usernameInput.error = "Invalid Username."
                }
            }
        }
    }
}