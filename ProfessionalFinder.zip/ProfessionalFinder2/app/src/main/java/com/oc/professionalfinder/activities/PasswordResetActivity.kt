package com.oc.professionalfinder.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.oc.professionalfinder.R
import com.oc.professionalfinder.databinding.ActivityPasswordResetBinding

class PasswordResetActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPasswordResetBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var navControl: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPasswordResetBinding.inflate(layoutInflater)
        setContentView(binding.root)
        resetEvents()
    }
    private fun resetEvents() {

        binding.btnResetSignUp.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }

        binding.btnNext.setOnClickListener{
            val email = binding.usernameInputEt.text.toString().trim()

            if (email.isNotEmpty()) {
                firebaseAuth.sendPasswordResetEmail(email).addOnCompleteListener {
                    if (it.isSuccessful) {
                        Toast.makeText(this, "Password reset email sent. Check your email inbox for further details.", Toast.LENGTH_SHORT).show()
                        navControl.navigate(R.id.action_passwordResetFragment_to_loginActivity)
                    } else {
                        Toast.makeText(this, it.exception?.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}