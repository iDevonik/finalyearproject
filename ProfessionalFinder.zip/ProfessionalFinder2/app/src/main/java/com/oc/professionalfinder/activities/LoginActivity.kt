@file:Suppress("DEPRECATION")

package com.oc.professionalfinder.activities

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.oc.professionalfinder.R
import com.oc.professionalfinder.databinding.ActivityLoginBinding
import com.oc.professionalfinder.fragments.loginRegister.PasswordResetFragment


class LoginActivity : AppCompatActivity() {

    lateinit var name: String
    private lateinit var email: String
    private lateinit var password: String
    private lateinit var auth: FirebaseAuth
    private lateinit var pds: ProgressDialog


    private lateinit var binding : ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)
        auth = FirebaseAuth.getInstance()


        if (auth.currentUser!=null){


            startActivity(Intent(this, MainMenuActivity::class.java))
            finish()

        }

        pds = ProgressDialog(this)

        binding.btnSignUpRedirect.setOnClickListener {

            startActivity(Intent(this, LoginRegisterActivity::class.java))


        }

        binding.btnForgottenPassword.setOnClickListener {
            startActivity(Intent(this, PasswordResetActivity::class.java))
        }


        binding.btnLogin.setOnClickListener {



            email = binding.usernameInputText.text.toString()
            password = binding.passwordInputText.text.toString()


            if (binding.usernameInputText.text.toString().isEmpty()){

                Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT).show()


            }


            if (binding.usernameInputText.text.toString().isEmpty()){

                Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show()


            }


            if (binding.usernameInputText.text.toString().isNotEmpty() && binding.passwordInputText.text.toString().isNotEmpty()){
                signIn(password, email)
            }
        }



    }

    private fun signIn(password: String, email: String) {
        pds.show()
        pds.setMessage("Signing In")

        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener {


            if (it.isSuccessful){
                if(auth.currentUser?.isEmailVerified == true){
                    pds.dismiss()
                    val intent = Intent(this, MainMenuActivity::class.java)
                    startActivity(intent)
                    finish()
                }else {

                    pds.dismiss()
                    Toast.makeText(applicationContext, "Please verify email", Toast.LENGTH_SHORT)
                        .show()
                    auth.currentUser?.sendEmailVerification()?.addOnCompleteListener {task -> if (task.isSuccessful) {
                        Toast.makeText(
                            applicationContext,
                            "Verification email sent to your corresponding email address. Please confirm to login.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }else {  Toast.makeText(
                        applicationContext,
                        "Verification email not sent. Please try again.",
                        Toast.LENGTH_SHORT
                    ).show()}
                }
                }


            } else {

                pds.dismiss()
                Toast.makeText(applicationContext, "Invalid Credentials", Toast.LENGTH_SHORT).show()


            }


        }.addOnFailureListener {exception->


            when (exception){

                is FirebaseAuthInvalidCredentialsException->{

                    Toast.makeText(applicationContext, "Invalid Credentials", Toast.LENGTH_SHORT).show()


                }

                else-> {

                    // other exceptions
                    Toast.makeText(applicationContext, "Auth Failed", Toast.LENGTH_SHORT).show()
                }

            }
        }



    }
}