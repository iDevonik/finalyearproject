package com.oc.professionalfinder.model

data class ToDo(var taskId:String, var task:String)
