package com.oc.professionalfinder.fragments.loginRegister

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.google.firebase.auth.FirebaseAuth
import com.oc.professionalfinder.R
import com.oc.professionalfinder.databinding.FragmentPasswordResetBinding

class PasswordResetFragment : Fragment(R.layout.fragment_password_reset) {
    private lateinit var binding: FragmentPasswordResetBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var navControl: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_password_reset, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init(view)
        resetEvents()
    }

    private fun init(view: View) {
        navControl = Navigation.findNavController(view)
        firebaseAuth = FirebaseAuth.getInstance()
    }

    private fun resetEvents() {

        binding.btnResetSignUp.setOnClickListener{
            navControl.navigate(R.id.action_passwordResetFragment_to_registerUsernameFragment2)
        }

        binding.btnNext.setOnClickListener{
            val email = binding.usernameInputEt.text.toString().trim()

            if (email.isNotEmpty()) {
                firebaseAuth.sendPasswordResetEmail(email).addOnCompleteListener {
                    if (it.isSuccessful) {
                        Toast.makeText(context, "Password reset email sent. Check your email inbox for further details.", Toast.LENGTH_SHORT).show()
                        navControl.navigate(R.id.action_passwordResetFragment_to_loginActivity)
                    } else {
                        Toast.makeText(context, it.exception?.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}