package com.oc.professionalfinder.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.oc.professionalfinder.databinding.EachJobsItemBinding
import com.oc.professionalfinder.databinding.EachTodoItemBinding
import com.oc.professionalfinder.model.ToDo
import com.oc.professionalfinder.model.User

class JobAdapter(private val list: MutableList<ToDo>) : RecyclerView.Adapter<JobAdapter.JobViewHolder>() {

    private  val TAG = "JobAdapter"
    private var listener:TaskAdapterInterface? = null
    fun setListener(listener:TaskAdapterInterface){
        this.listener = listener
    }
    class JobViewHolder(val binding: EachJobsItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val binding =
            EachJobsItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JobViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        val currentTask = list[position]
        with(holder) {
            with(list[position]) {
                binding.jobTask.text = this.task
                Log.d(TAG, "onBindViewHolder: "+this)

            }
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface TaskAdapterInterface{
        fun onDeleteItemClicked(toDoData: ToDo , position : Int)
        fun onEditItemClicked(toDoData: ToDo , position: Int)
    }

}