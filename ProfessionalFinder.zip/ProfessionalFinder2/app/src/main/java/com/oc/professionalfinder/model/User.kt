package com.oc.professionalfinder.model


data class User(

    val userid: String? = "",
    val imageUrl : String? = "",
    val username: String? = "",
    val useremail : String? ="",
    val bio : String? = "",
    val expertise : String? = "",
    val jobRequest : String? = ""
    )