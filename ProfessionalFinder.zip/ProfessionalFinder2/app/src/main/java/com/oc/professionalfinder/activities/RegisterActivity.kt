package com.oc.professionalfinder.activities

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.navigation.navArgs
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.oc.professionalfinder.R
import com.oc.professionalfinder.databinding.ActivityRegisterBinding
import com.oc.professionalfinder.model.User
import java.util.regex.Pattern


class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth : FirebaseAuth
    private lateinit var firestore : FirebaseFirestore
    private lateinit var email: String
    private lateinit var password: String
    private val args : RegisterActivityArgs by navArgs()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()


        binding.textSignInRedirect.setOnClickListener {

            startActivity(Intent(this, LoginActivity::class.java))
        }
        binding.btnNext.setOnClickListener {
            // Reset the error outputs if user has clicked the button again after correcting issues
            binding.usernameInput.isErrorEnabled = false
            binding.passwordInput.isErrorEnabled = false
            binding.passwordInput2.isErrorEnabled = false

            val isEmailValid = isValidEmail(binding.usernameInputEt.text.toString())
            val isPasswordValid = isValidPassword(binding.passwordInputEt.text.toString())
            val username= args.username
            email = binding.usernameInputEt.text.toString()
            password = binding.passwordInputEt.text.toString()

            // Validation checks to see if inputted values are correct.
            if (username.isEmpty()){

                Toast.makeText(this, "Prior inputted values are incorrect. Please try again.", Toast.LENGTH_SHORT).show()


            }


            if (binding.usernameInputEt.text.toString().isEmpty()){
                binding.usernameInput.error = "Email not inputted."
            }
            if (!isEmailValid) {
                binding.usernameInput.error = "Valid email input not inputted."
            }


            if (!isPasswordValid) {
                binding.passwordInput.error = "Valid password format not inputted."
            }
            if (binding.passwordInputEt.text.toString().isEmpty()){

                binding.passwordInput.error = "Password not inputted."
            }
            if (binding.passwordInputEt.text.toString().length < 6){
                binding.passwordInput2.error = "Password has to be at least 6 characters long."
                }

            if (binding.passwordInput2Et.text.toString().isEmpty()){

                binding.passwordInput2.error = "Password not inputted."
            }

            if (binding.passwordInputEt.text.toString() != binding.passwordInput2Et.text.toString()){

                binding.passwordInput2.error = "Passwords don't match."

            }


            if (username.isNotEmpty() && binding.usernameInputEt.text.toString().isNotEmpty() && binding.passwordInputEt.text.toString().isNotEmpty() &&
                (binding.passwordInputEt.text.toString() == binding.passwordInput2Et.text.toString() && (isEmailValid) && (isPasswordValid))){
                //createAnAccount(username, password, email)
                storeData(username, password, email)
            }
        }

    }
    fun setInProgress(inProgress : Boolean){
        if(inProgress){
            binding.progressBar.visibility = View.VISIBLE
            binding.btnNext.visibility = View.GONE
        }else{
            binding.progressBar.visibility = View.GONE
            binding.btnNext.visibility = View.VISIBLE
        }
    }
    // Validation check which sees if the email input matches the email format, which will then output true if so.
    fun isValidEmail(email: String): Boolean {
        val emailRegex = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
        )
        return emailRegex.matcher(email).matches()
    }
    fun isValidPassword(password: String): Boolean {
        val passwordPattern = "^(?=.*[!@#\$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{1,}\$"
        val passwordMatcher = Regex(passwordPattern)

        return passwordMatcher.containsMatchIn(password.trim())
    }
    private fun storeData(username: String, password: String, email: String){
        setInProgress(true)
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            val user = auth.currentUser
            val data = User(
                userid = user!!.uid,
                //Default image
                imageUrl = "https://static.vecteezy.com/system/resources/thumbnails/001/840/612/small/picture-profile-icon-male-icon-human-or-people-sign-and-symbol-free-vector.jpg",
                username = username,
                useremail = email,
                expertise = "",
                bio = ""
            )
            FirebaseDatabase.getInstance().getReference("User")
                .child(FirebaseAuth.getInstance().currentUser!!.uid).setValue((data))
                .addOnCompleteListener {
                    if (it.isSuccessful) {
                        setInProgress(false)
                        Toast.makeText(
                            this,
                            "Registration successful. Please verify your email address before proceeding.",
                            Toast.LENGTH_SHORT
                        ).show()
                        auth.currentUser?.sendEmailVerification()
                        auth.signOut()
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this, it.exception!!.message, Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}