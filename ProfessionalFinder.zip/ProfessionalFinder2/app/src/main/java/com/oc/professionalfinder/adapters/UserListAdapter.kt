package com.oc.professionalfinder.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.oc.professionalfinder.R
import com.oc.professionalfinder.activities.ChatActivity
import com.oc.professionalfinder.databinding.UserItemLayoutBinding
import com.oc.professionalfinder.model.User

class UserListAdapter(val context: Context, var userList: ArrayList<User>):
    RecyclerView.Adapter<UserListAdapter.UserViewHolder>() {

        inner class UserViewHolder(val binding: UserItemLayoutBinding)
            : RecyclerView.ViewHolder(binding.root)

    fun setFilteredList(userList: ArrayList<User>){
        this.userList = userList
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        return UserViewHolder(UserItemLayoutBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val currentUser = userList[position]

        holder.itemView.setOnClickListener{
            val intent = Intent(context, ChatActivity::class.java)

            intent.putExtra("username",currentUser.username)
            intent.putExtra("userid",currentUser.userid)

            context.startActivity(intent)
        }
        // Adds data to the fields on the recycler view item
        holder.binding.userNameLayout.text = currentUser.username
        holder.binding.userExpertiseLayout.text = "Expertise: " + currentUser.expertise
        Glide.with(context).load(userList[position].imageUrl).into(holder.binding.userImageLayout)


    }

    override fun getItemCount(): Int {
        return userList.size
    }

    }