package com.oc.professionalfinder.fragments.mainMenu

import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.oc.professionalfinder.R
import com.oc.professionalfinder.databinding.FragmentProfileBinding
import com.oc.professionalfinder.model.User
import java.io.File

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class profileFragment : Fragment() {
    private lateinit var navControl: NavController
    private lateinit var binding: FragmentProfileBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var dbReference: DatabaseReference
    private lateinit var stReference: StorageReference
    lateinit var profileUser: com.oc.professionalfinder.model.User
    lateinit var uid: String
    lateinit var profileUri: Uri
    lateinit var photoLauncher: ActivityResultLauncher<Intent>
    private lateinit var pd : ProgressDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(layoutInflater)
        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        dbReference = FirebaseDatabase.getInstance().getReference("User")
        if (uid.isNotEmpty()) {
            getUserData()
        }
        photoLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == AppCompatActivity.RESULT_OK) {
                    setInProgress(true)
                    uploadProfilePic(result.data?.data!!)
                }
            }
        editUser()
        logOut()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navSet(view)
    }

    private fun navSet(view: View) {
        navControl = Navigation.findNavController(view)
    }


    private fun logOut() {
        binding.btnSignOut.setOnClickListener {
            auth.signOut()
        }
    }

    private fun uploadProfilePic(photoUri: Uri) {
        profileUri = photoUri
        stReference = FirebaseStorage.getInstance().getReference("User/" + FirebaseAuth.getInstance().currentUser?.uid)
        stReference.putFile(profileUri).addOnSuccessListener {
            Toast.makeText(requireActivity(), "Image successfully uploaded", Toast.LENGTH_SHORT).show()
            dbReference = FirebaseDatabase.getInstance().getReference("User")
            stReference.downloadUrl.addOnSuccessListener { downloadUrl ->
                val image = mapOf("imageUrl" to downloadUrl.toString())
                dbReference.child(uid).updateChildren(image).addOnCompleteListener {
                    if (it.isSuccessful) {
                        getUserData()
                    }
                }
            }.addOnFailureListener {
                Toast.makeText(requireActivity(), "Failed to retrieve profile pic", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Picture Picker

    // Starts looking for data from database to populate the profile activity
    private fun getUserData() {
        dbReference.child(uid).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                profileUser = snapshot.getValue(User::class.java)!!
                binding.username.setText("@"+ profileUser.username)
                binding.txtBio.text = profileUser.bio.toString()
                binding.txtExpertise.text= profileUser.expertise.toString()
                getUserProfile()
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }
    // Pulls data from DB and displays on the profile activity
    private fun getUserProfile() {
        stReference = FirebaseStorage.getInstance().reference.child("User/$uid")
        val localFile = File.createTempFile("tempImage","jpg")
        stReference.getFile(localFile).addOnSuccessListener {
            val bitmap = BitmapFactory.decodeFile((localFile.absolutePath))
            binding.profilePic.setImageBitmap(bitmap)
            setInProgress(false)
        }.addOnFailureListener{
        }
    }
    private fun editUser() {
        binding.btnProfile.setOnClickListener {
            navControl.navigate(R.id.action_profileFragment_to_profileEditFragment)
        }


    }
    fun setInProgress(inProgress : Boolean){
        if(inProgress){
            binding.progressBar.visibility = View.VISIBLE
            binding.btnProfile.visibility = View.GONE
            binding.username.visibility = View.GONE
            binding.profilePic.visibility = View.GONE
            binding.mDivider.visibility = View.GONE
        }else{
            binding.progressBar.visibility = View.GONE
            binding.btnProfile.visibility = View.VISIBLE
            binding.profilePic.visibility = View.VISIBLE
            binding.username.visibility = View.VISIBLE
            binding.mDivider.visibility = View.VISIBLE
        }
    }

}